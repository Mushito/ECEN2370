/*
 * ApplicationCode.c
 *
 *  Created on: Jan 30, 2025
 *      Author: willa
 */


#include "ApplicationCode.h"

char nameArray[NAME_LENGTH] = {'W','I','L','L'};
char destinationArray[NAME_LENGTH];

void greenLEDInit(){
    LED_Init(GREEN_LED);
}

void redLEDInit(){
    LED_Init(RED_LED);
}

void LEDInitAll() {
    redLEDInit();
    greenLEDInit();
}

void toggleGreenLED(){
    toggleLED(GREEN_LED);
}

void toggleRedLED(){
    toggleLED(RED_LED);
}

void activateGreenLED(){
    turnOnLED(GREEN_LED);
}

void activateRedLED(){
    turnOnLED(RED_LED);
}

void deactivateGreenLED(){
    turnOffLED(GREEN_LED);
}

void deactivateRedLED(){
    turnOffLED(RED_LED);
}

void appDelay(uint32_t delay){
	int i;
	int j;
	for (i = 0; i <= delay; i++){
		for (j = 0; j <= NAME_LENGTH; j++){
			destinationArray[j] = nameArray[j];
		}
	}
}

void applicationInit(){
    greenLEDInit();
    redLEDInit();
    deactivateGreenLED();
    deactivateRedLED();

    TimerInit(GPTIMR);

    #if TRACK_USER_INPUT
        I_ModeButtonInit();
    #else
        TimerStart(GPTIMR);
    
    #endif

    addSchedulerEvent(DELAY_EVENT);

    #if USE_INTERRUPT_FOR_BUTTON
        I_ModeButtonInit();

    #else
        buttonInit();
        addSchedulerEvent(POLLING_EVENT);
    #endif
}

void appButtonInit(){
    buttonInit();
}

void executeButtonPollingRoutine(){
    uint8_t pressed = buttonPressed();
    if (pressed == ACTIVE)
        activateGreenLED();
    else
        deactivateGreenLED();
}

void EXTI0_IRQHandler(){
    disableIRQ(EXTI0_IRQ_NUMBER);
	#if TRACK_USER_INPUT == ACTIVE

    uint8_t pressed = buttonPressed();
    volatile uint8_t buttonPressedFlag = 0;

    if(pressed == ACTIVE && buttonPressedFlag == INACTIVE){
    	buttonPressedFlag = ACTIVE;
    	TimerRst(GPTIMR);
    	TimerStart(GPTIMR);
    }
    if(pressed == INACTIVE && buttonPressedFlag == ACTIVE){
    	buttonPressedFlag = 2;
    	uint32_t userHoldDuration = GPTIMR->CNT;
    	GPTIMR->ARR = userHoldDuration;

    	TimerRst(GPTIMR);
    }

	#else
    	toggleGreenLED();

	#endif
    clrPendingBit(0);
    enableIRQ(EXTI0_IRQ_NUMBER);   
}

void TIM2_IRQHandler(){
    disableIRQ(TIM2_IRQ_NUMBER);
        toggleRedLED();
        clearUpdateInterruptFlag(GPTIMR);
    enableIRQ(TIM2_IRQ_NUMBER);
}



void I_ModeButtonInit(){
    GPIO_PinConfig_t pinConfig;
    
    pinConfig.PinNumber       = USER_BUTTON_PIN_NUM;
    pinConfig.PinMode         = GPIO_PINMODE_INPUT;    
    pinConfig.OPType          = GPIO_OPTYPE_PUSH_PULL;
    pinConfig.PinSpeed        = GPIO_SPEEDR_HIGH;    
    pinConfig.PinPuPdControl  = GPIO_PUPDR_NONE;       
    pinConfig.PinInterruptMode= IMODE_FRE;               
    
    GPIO_Init(GPIOA, &pinConfig);

    NVIC_Handler(EXTI0_IRQ_NUMBER, ACTIVE);
    NVIC_Handler(TIM2_IRQ_NUMBER, ACTIVE); /////NEEDED?
}
