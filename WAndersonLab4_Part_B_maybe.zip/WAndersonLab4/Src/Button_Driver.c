#include <Button_Driver.h>

void buttonInit(){
    GPIO_PinConfig_t pinConfig;
    pinConfig.PinNumber = USER_BUTTON_PIN_NUM;
    pinConfig.PinMode = GPIO_PINMODE_INPUT;
    pinConfig.OPType = GPIO_OPTYPE_PUSH_PULL;
    pinConfig.PinSpeed = GPIO_SPEEDR_HIGH;
    pinConfig.PinPuPdControl = GPIO_PUPDR_NONE;

    GPIO_Init(GPIOA, &pinConfig);
}

uint8_t buttonPressed(){
    uint8_t pinVal = GPIO_ReadPin(GPIOA, USER_BUTTON_PIN_NUM);
    if (pinVal == USER_BUTTON_PRESSED)
        return ACTIVE;
    else
        return INACTIVE;
}

void I_Mode_Init(){
    GPIO_PinConfig_t pinConfig;
    pinConfig.PinNumber = USER_BUTTON_PIN_NUM;
    pinConfig.PinMode = GPIO_PINMODE_INPUT;
    pinConfig.OPType = GPIO_OPTYPE_PUSH_PULL;
    pinConfig.PinSpeed = GPIO_SPEEDR_HIGH;
    pinConfig.PinPuPdControl = GPIO_PUPDR_NONE;
    pinConfig.PinInterruptMode = IMODE_FRE;

    GPIO_Init(GPIOA, &pinConfig);

    NVIC_Handler(EXTI0_IRQ_NUMBER, ACTIVE);
}
