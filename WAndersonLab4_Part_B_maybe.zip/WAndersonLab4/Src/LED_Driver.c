#include "LED_Driver.h"

void LED_Init(uint8_t ledNum){
    GPIO_PinConfig_t pinConfig;

    switch (ledNum){
        case RED_LED:
            pinConfig.PinNumber = RED_LED_PIN;
            pinConfig.PinMode = GPIO_PINMODE_GPO;
            pinConfig.OPType = GPIO_OPTYPE_PUSH_PULL;
            pinConfig.PinSpeed = GPIO_SPEEDR_HIGH;
            pinConfig.PinPuPdControl = GPIO_PUPDR_NONE;

            GPIO_Init(GPIOG, &pinConfig);

            break;
        
        case GREEN_LED:
            pinConfig.PinNumber = GREEN_LED_PIN;
            pinConfig.PinMode = GPIO_PINMODE_GPO;
            pinConfig.OPType = GPIO_OPTYPE_PUSH_PULL;
            pinConfig.PinSpeed = GPIO_SPEEDR_HIGH;
            pinConfig.PinPuPdControl = GPIO_PUPDR_NONE;

            GPIO_Init(GPIOG, &pinConfig);

            break;

        default:
            return;
    }
}

void toggleLED(uint8_t ledNum){
    switch(ledNum){
        case RED_LED:
            GPIO_ToggleOutputPin(GPIOG, RED_LED_PIN);

            break;

        case GREEN_LED:
            GPIO_ToggleOutputPin(GPIOG, GREEN_LED_PIN);

            break;

        default:
            return;
    }
}

void turnOffLED(uint8_t ledNum){
      switch (ledNum) {
        case RED_LED:
            GPIO_WriteToOutputPin(GPIOG, RED_LED_PIN, INACTIVE);

            break;
        
        case GREEN_LED:
            GPIO_WriteToOutputPin(GPIOG, GREEN_LED_PIN, INACTIVE);

             break;

        default:
            return;
      }
}

void turnOnLED(uint8_t ledNum){
      switch (ledNum) {
        case RED_LED:
            GPIO_WriteToOutputPin(GPIOG, RED_LED_PIN, ACTIVE);

            break;
        
        case GREEN_LED:
            GPIO_WriteToOutputPin(GPIOG, GREEN_LED_PIN, ACTIVE);

             break;

        default:
            return;
      }
}

void LED_TimerInit(GPTimer_Config_t *pinConfig){
    pinConfig->CKD  = CKD_1;
    pinConfig->ARPE = INACTIVE;
    pinConfig->CMS  = CMS_EAM;
    pinConfig->DIR  = DIR_UP;
    pinConfig->OPM  = OPM_OFF;
    pinConfig->URS  = ACTIVE;
    pinConfig->UDIS = UDIS_ON;
    pinConfig->MMS  = MMS_RST; //IDK IF THIS IS RIGHT
    pinConfig->ARV  = 63999999;
    pinConfig->PSC  = 0;
}

void LED_TimerStart(){
    TimerStart(GPTIMR);
}

void LED_TimerStop(){
    TimerStop(GPTIMR);
}

void LED_TimerRst(){
    TimerRst(GPTIMR);
}

uint32_t LED_TimerGetARV(){
    return GPTIMR->ARR;
}

uint32_t LED_TimerGetCountVal(){//MIGHT NOT BE UINT32
    return GPTIMR->CNT;
}

//void LED_TimerARV_Reconfig(GPTIMR_RegDef_t *TIMRptr, uint32_t config){
//    GPTIMR->ARV = config;
//}
