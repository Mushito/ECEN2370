/*
 * GPIO_Driver.c
 *
 *  Created on: Jan 30, 2025
 *      Author: willa
 */
#include <GPIO_Driver.h>

void GPIO_ClockControl(GPIO_RegDef_t *pConfigPtr, uint8_t onOff){
    if (onOff == ACTIVE){
        if (pConfigPtr == GPIOG)
            GPIO_CLK_EN(GPIOG_OFFSET);
        else
            GPIO_CLK_EN(GPIOA_OFFSET);
    }
    else{
        if (pConfigPtr == GPIOG)
            GPIO_CLK_DIS(GPIOG_OFFSET);
        else
            GPIO_CLK_DIS(GPIOA_OFFSET);
    }
}

void GPIO_WriteToOutputPin(GPIO_RegDef_t *pConfigPtr, uint8_t pinNum, uint8_t pinVal){
    if(pinVal == ACTIVE){
        pConfigPtr->ODR |= (0x1 << pinNum);
    }
    else
        pConfigPtr->ODR &= ~(0x1 << pinNum);
}

void GPIO_ToggleOutputPin(GPIO_RegDef_t *pConfigPtr, uint8_t pinNum) {
    if (pConfigPtr->ODR & (1 << pinNum)) {
        pConfigPtr->ODR &= ~(1 << pinNum);
    } else {
        pConfigPtr->ODR |= (1 << pinNum);
    }
}


void GPIO_Init(GPIO_RegDef_t *portPtr, GPIO_PinConfig_t *pinConfig) {

	GPIO_ClockControl(portPtr, ACTIVE);
	GPIO_ClockControl(GPIOG, ACTIVE);

    uint32_t temp;

    temp = (pinConfig->PinMode << (GPIO_MODE_SHIFT * pinConfig->PinNumber));
    portPtr->MODER &= ~(0x3 << (GPIO_MODE_SHIFT * pinConfig->PinNumber));
    portPtr->MODER |= temp;

    temp = (pinConfig->PinSpeed << (GPIO_MODE_SHIFT * pinConfig->PinNumber));
    portPtr->OSPEEDR &= ~(0x3 << (GPIO_MODE_SHIFT * pinConfig->PinNumber));
    portPtr->OSPEEDR |= temp;

    temp = (pinConfig->PinPuPdControl << (GPIO_MODE_SHIFT * pinConfig->PinNumber));
    portPtr->PUPDR &= ~(0x3 << (GPIO_MODE_SHIFT * pinConfig->PinNumber));
    portPtr->PUPDR |= temp;

    temp = (pinConfig->OPType << pinConfig->PinNumber);
    portPtr->OTYPER &= ~(0x1 << pinConfig->PinNumber);
    portPtr->OTYPER |= temp;

    if (pinConfig->PinInterruptMode != IMODE_NONE)
    {
        if (pinConfig->PinInterruptMode == IMODE_FE) {
            EXTI->FTSR |= (1 << pinConfig->PinNumber); 
            EXTI->RTSR &= ~(1 << pinConfig->PinNumber);
        } else if (pinConfig->PinInterruptMode == IMODE_RE) {
            EXTI->RTSR |= (1 << pinConfig->PinNumber);
            EXTI->FTSR &= ~(1 << pinConfig->PinNumber); 
        } else if (pinConfig->PinInterruptMode == IMODE_FRE) {
            EXTI->FTSR |= (1 << pinConfig->PinNumber); 
            EXTI->RTSR |= (1 << pinConfig->PinNumber);  
        }
    }

        uint8_t extiRegIndex = pinConfig->PinNumber / 4;
        uint8_t extiBitPos = (pinConfig->PinNumber) % 4;
        uint16_t portCode = GetPortNum(portPtr);

        SYSCFG_CLK_EN;

        SYSCFG->SYSCFG_EXTICR[extiRegIndex] |= (portCode << (extiBitPos*SYSCFG_EXTICR_OFFSET));

        EXTI->IMR |= (1 << pinConfig->PinNumber);
}

uint8_t GPIO_ReadPin(GPIO_RegDef_t *pConfigPtr, uint8_t pinNum){
    uint8_t Val = ((pConfigPtr->IDR >> pinNum) & 0x01);
    return Val;
}

uint32_t GetPortNum(GPIO_RegDef_t *GPIOx){
    if(GPIOx == GPIOA)
    	return PORT_NUM_A;
    if(GPIOx == GPIOG)
    	return PORT_NUM_G;
    return 0;
}

void NVIC_Handler(uint8_t IRQnum, uint8_t onOff){
    if (onOff)
        enableIRQ(IRQnum);
    else
        disableIRQ(IRQnum);
}
