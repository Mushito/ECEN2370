/*
 * GPIO_Driver.h
 *
 *  Created on: Jan 30, 2025
 *      Author: willa
 */

#ifndef GPIO_DRIVER_H_
#define GPIO_DRIVER_H_

#include "STM32F429i.h"
#include "InterruptControl.h"

typedef struct
{
uint8_t PinNumber; // Pin Number
uint8_t PinMode; // Pin Mode
uint8_t OPType; // Output Type
uint8_t PinSpeed; // Pin Speed
uint8_t PinPuPdControl; // Pin Push up/ Pull Down Control
uint8_t PinInterruptMode; // interrupt mode
}GPIO_PinConfig_t;

#define IMODE_NONE 00
#define IMODE_FE 01
#define IMODE_RE 10
#define IMODE_FRE 11

#define PORT_NUM_A 0
#define PORT_NUM_B 1
#define PORT_NUM_C 2
#define PORT_NUM_G 6


#define GPIO_PIN_NUM_0 0
#define GPIO_PIN_NUM_1 1
#define GPIO_PIN_NUM_2 2
#define GPIO_PIN_NUM_3 3
#define GPIO_PIN_NUM_4 4
#define GPIO_PIN_NUM_5 5
#define GPIO_PIN_NUM_6 6
#define GPIO_PIN_NUM_7 7
#define GPIO_PIN_NUM_8 8
#define GPIO_PIN_NUM_9 9
#define GPIO_PIN_NUM_10 10
#define GPIO_PIN_NUM_11 11
#define GPIO_PIN_NUM_12 12
#define GPIO_PIN_NUM_13 13
#define GPIO_PIN_NUM_14 14
#define GPIO_PIN_NUM_15 15

#define GPIO_PINMODE_INPUT 00
#define GPIO_PINMODE_GPO 01
#define GPIO_PIN_MODE_AFM 10
#define GPIO_PINMODE_AM 11

#define GPIO_OPTYPE_PUSH_PULL 0
#define GPIO_OPTYPE_OPEN_DRAIN 1

#define GPIO_SPEEDR_LOW 00
#define GPIO_SPEEDR_MED 01
#define GPIO_SPEEDR_HIGH 10
#define GPIO_SPEEDR_VHI 11

#define GPIO_PUPDR_NONE 00
#define GPIO_PUPDR_PU 01
#define GPIO_PUPDR_PD 10
#define GPIO_PUPDR_RSRV 11

#define GPIO_MODE_SHIFT 2


void GPIO_Init(GPIO_RegDef_t *portPtr, GPIO_PinConfig_t *pinConfig);

void GPIO_ClockControl(GPIO_RegDef_t *pConfigPtr, uint8_t onOff);

void GPIO_WriteToOutputPin(GPIO_RegDef_t *pConfigPtr, uint8_t pinNum, uint8_t pinVal);

void GPIO_ToggleOutputPin(GPIO_RegDef_t *pConfigPtr, uint8_t pinNum);

uint8_t GPIO_ReadPin(GPIO_RegDef_t *pConfigPtr, uint8_t pinNum);

uint32_t GetPortNum(GPIO_RegDef_t *GPIOx);

void NVIC_Handler(uint8_t IRQnum, uint8_t onOff);


#endif /* GPIO_DRIVER_H_ */
