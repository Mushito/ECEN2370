/*
 * STM32F429i.h
 *
 *  Created on: Jan 30, 2025
 *      Author: willa
 */

#ifndef STM32F429I_H_
#define STM32F429I_H_

#include <stdint.h>

typedef struct{
	volatile uint32_t MODER;
	volatile uint32_t OTYPER;
	volatile uint32_t OSPEEDR;
	volatile uint32_t PUPDR;
	volatile uint32_t IDR;
	volatile uint32_t ODR;
	volatile uint32_t BSRR;
	volatile uint32_t LCKR;
	volatile uint32_t AFR[2];
}GPIO_RegDef_t;

typedef struct{
	volatile uint32_t CR;
	volatile uint32_t PLLCFGR;
	volatile uint32_t CFGR;
	volatile uint32_t CIR;
	volatile uint32_t AHB1RSTR;
	volatile uint32_t AHB2RSTR;
	volatile uint32_t AHB3RSTR;
	volatile uint32_t RSRV1;
	volatile uint32_t APB1RSTR;
	volatile uint32_t APB2RSTR;
	volatile uint32_t RSRV2[2];
	volatile uint32_t AHB1ENR;
	volatile uint32_t AHB2ENR;
	volatile uint32_t AHB3ENR;
	volatile uint32_t RSRV3;
	volatile uint32_t APB1ENR;
	volatile uint32_t APB2ENR;
	volatile uint32_t RSRV4[2];
	volatile uint32_t AHB1LPENR;
	volatile uint32_t AHB2LPENR;
	volatile uint32_t AHB3LPENR;
	volatile uint32_t RSRV5;
	volatile uint32_t APB1LPENR;
	volatile uint32_t APB2LPENR;
	volatile uint32_t RSRV6[2];
	volatile uint32_t BDCR;
	volatile uint32_t CSR;
	volatile uint32_t RSRV7[2];
	volatile uint32_t SSCGR;
	volatile uint32_t PLLI2SCFGR;
	volatile uint32_t PLLSAICFGR;
	volatile uint32_t DCKCFGR;
}RCC_RegDef_t;

#define NVIC_SET_ENABLE ((volatile uint32_t*) 0xE000E100)
#define NVIC_CLEAR_ENABLE ((volatile uint32_t*) 0XE000E180)
#define NVIC_CLEAR_PENDING ((volatile uint32_t*) 0XE000E280)

#define APB2_BASE_ADDR (0x40013800)
#define SYSCFG_BASE_ADDR (APB2_BASE_ADDR + 0)
#define EXTI_BASE_ADDR (APB2_BASE_ADDR + 0x400)

typedef struct{
    volatile uint32_t SYSCFG_MEMRMP;
    volatile uint32_t SYSCFG_PMC;
    volatile uint32_t SYSCFG_EXTICR[4];
    volatile uint32_t SYSCFG_CMPCR;
}SYSCFG_RegDef_t;

typedef struct 
{
    volatile uint32_t IMR;
    volatile uint32_t EMR;
    volatile uint32_t RTSR;
    volatile uint32_t FTSR;
    volatile uint32_t SWIER;
    volatile uint32_t PR;
}EXTI_RegDef_t;

typedef struct 
{
	volatile uint32_t CR1;
	volatile uint32_t CR2;
	volatile uint32_t SMCR;
	volatile uint32_t DIER;
	volatile uint32_t SR;
	volatile uint32_t EGR;
	volatile uint32_t CCMR1;
	volatile uint32_t CCMR2;
	volatile uint32_t CCER;
	volatile uint32_t CNT;
	volatile uint32_t PSC;
	volatile uint32_t ARR;
	volatile uint32_t RSRV1;
	volatile uint32_t CCR1;
	volatile uint32_t CCR2;
	volatile uint32_t CCR3;
	volatile uint32_t CCR4;
	volatile uint32_t RSRV2;
	volatile uint32_t DCR;
	volatile uint32_t DMAR;
	volatile uint32_t OR;
}GPTIMR_RegDef_t;

#define GPTIMR ((GPTIMR_RegDef_t*) TIM2_BASE_ADDR)

#define EXTI ((EXTI_RegDef_t*) EXTI_BASE_ADDR)
#define SYSCFG ((SYSCFG_RegDef_t*) SYSCFG_BASE_ADDR)

#define SYSCFG_CLK_OFFSET 14

#define SYSCFG_CLK_EN (RCC->APB2RSTR |= (1 << SYSCFG_CLK_OFFSET))
#define SYSCFG_CLK_DIS (RCC->APB2RSTR &= ~(1 << SYSCFG_CLK_OFFSET))


#define RCC_BASE_ADDR (0x40020000 + 0x3800)

#define GPIOG_BASE_ADDR (0x40020000 + 0x1800)

#define GPIOA_BASE_ADDR (0x40020000)


#define TIM2_BASE_ADDR 0x40000000


#define GPIOG ((GPIO_RegDef_t*) GPIOG_BASE_ADDR)
#define GPIOA ((GPIO_RegDef_t*) GPIOA_BASE_ADDR)

#define RCC ((RCC_RegDef_t*) RCC_BASE_ADDR)


static inline void GPIO_CLK_EN(uint16_t regOffset) {
    RCC->AHB1ENR |= (1 << regOffset);
}
static inline void GPIO_CLK_DIS(uint16_t regOffset) {
    RCC->AHB1ENR &= ~(1 << regOffset);
}

static inline void TIM2_CLK_EN(){
	RCC->APB1ENR |= (1 << 0);
}
static inline void TIM2_CLK_DIS(){
	RCC->APB1ENR &= ~(1 << 0);
}


#define GPIOG_OFFSET 6
#define GPIOA_OFFSET 0

#define SYSCFG_EXTICR_OFFSET 4

#define ACTIVE 1
#define INACTIVE 0
#define SET 1
#define RESET 0
#define ENABLE SET
#define DISABLE RESET

#endif /* STM32F429I_H_ */
