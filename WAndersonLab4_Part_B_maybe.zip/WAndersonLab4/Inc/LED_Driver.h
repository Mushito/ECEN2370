/*
 * LED_Driver.h
 *
 *  Created on: Jan 30, 2025
 *      Author: willa
 */

#ifndef LED_DRIVER_H_
#define LED_DRIVER_H_

#include "GPIO_Driver.h"
#include "Timer_Driver.h"

#define RED_LED 1
#define GREEN_LED 0

#define RED_LED_PIN 14
#define GREEN_LED_PIN 13


void LED_Init(uint8_t ledNum);

void toggleLED(uint8_t ledNum);

void turnOffLED(uint8_t ledNum);

void turnOnLED(uint8_t ledNum);

void LED_TimerInit();

void LED_TimerStart();

void LED_TimerStop();

void LED_TimerRst();

uint32_t LED_TimerGetARV();

uint32_t LED_TimerGetCountVal(); //////MIGHT NOT BE UINT32

void LED_TimerARV_Reconfig(uint32_t config);

#endif /* LED_DRIVER_H_ */
