/*
 * Timer_Driver.h
 *
 *  Created on: Feb 27, 2025
 *      Author: willa
 */

#ifndef TIMER_DRIVER_H_
#define TIMER_DRIVER_H_

#include "STM32F429i.h"
#include "InterruptControl.h"

typedef struct
{
    uint32_t  ARV;               //Auto Reload Value
    uint32_t  MMS;           //Master Mode Selection
    uint32_t  CKD;        //Clock Division Selection
    uint32_t  PSC;                 //Prescaler Value
    uint32_t  CMS;   //Center Aligned Mode Selection
    uint8_t   ARPE;  //Auto reload buffer enablement
    uint8_t   DIR;//Timer count-down mode enablement
    uint8_t   URS;     //Interrupt update enablement
    uint8_t   UDIS;           //Disable update event
    uint8_t   OPM;       //One pulse mode enablement
}   GPTimer_Config_t;

void TimerInit(GPTIMR_RegDef_t *TIMRptr);

void TimerClkCtrl(uint8_t onOff); //MIGHT NEED TO PASS IN GPTIMR_RegDef_t *TIMRptr

void TimerStart(GPTIMR_RegDef_t *TIMRptr);

void TimerStop(GPTIMR_RegDef_t *TIMRptr);

void TimerRst(GPTIMR_RegDef_t *TIMRptr);

uint32_t getTimerCnt(GPTIMR_RegDef_t *TIMRptr);

void TimerInterrupt(GPTIMR_RegDef_t *TIMRptr);

uint32_t getTimerARV(GPTIMR_RegDef_t *TIMRptr);

void clearUpdateInterruptFlag(GPTIMR_RegDef_t *TIMRptr);

#define MMS_RST         000
#define MMS_ENABLE      001
#define MMS_UPDATE      010
#define MMS_CMP_PLSE    011
#define MMS_CMP_OC1     100
#define MMS_CMP_OC2     101
#define MMS_CMP_OC3     110
#define MMS_CMP_OC4     111

#define CKD_1 00
#define CKD_2 01
#define CKD_4 10

#define CMS_EAM  00 //EDGE ALIGNED MODE
#define CMS_CAM1 01 //CENTER ALIGNED MODE 1
#define CMS_CAM2 10
#define CMS_CAM3 11

#define DIR_UP  0
#define DIR_DWN 1

#define OPM_OFF 0
#define OPM_ON  1

#define URS_CNTR 0
#define URS_ALL  1

#define UDIS_ON  0
#define UDIS_OFF 1

#define CKD_OFFSET  8
#define CMS_OFFSET  5
#define DIR_OFFSET  4
#define ARPE_OFFSET 7
#define OPM_OFFSET  3
#define UDIS_OFFSET 1
#define URS_OFFSET  2

#endif /* TIMER_DRIVER_H_ */
