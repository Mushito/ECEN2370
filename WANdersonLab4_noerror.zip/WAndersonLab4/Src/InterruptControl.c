/*
 * InterruptControl.c
 *
 *  Created on: Feb 19, 2025
 *      Author: willa
 */
#include <InterruptControl.h>

void enableIRQ(uint8_t IRQnum){
    if (IRQnum < 32)
        *NVIC_SET_ENABLE = (1 << IRQnum);
}

void disableIRQ(uint8_t IRQnum){
    if (IRQnum < 32)
    *NVIC_CLEAR_ENABLE = (1 << IRQnum);
}

void clrPendingIRQ(uint8_t IRQnum){
    if (IRQnum < 32)
    *NVIC_CLEAR_PENDING = (1 << IRQnum);
}

void clrPendingBit(uint8_t pinNum){
	if(pinNum <32)
		EXTI->PR = (1 << pinNum);
}
