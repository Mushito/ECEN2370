/*
 * Timer_Driver.c
 *
 *  Created on: Feb 27, 2025
 *      Author: willa
 */
#include "Timer_Driver.h"

void TimerClkCtrl(uint8_t onOff){
    if(onOff == ACTIVE)
        TIM2_CLK_EN();
    else
        TIM2_CLK_DIS();
}


void TimerInit(GPTIMR_RegDef_t *TIMRptr, GPTimer_Config_t config){
    TimerClkCtrl(ACTIVE);
        
    uint32_t temp;

    temp = (config.CKD << (CKD_OFFSET));
    TIMRptr->CR1 &= ~(0x3 << (CKD_OFFSET));
    TIMRptr->CR1 |= temp;

    temp = (config.CMS << (CMS_OFFSET));
    TIMRptr->CR1 &= ~(0x3 << (CMS_OFFSET));
    TIMRptr->CR1 |= temp;

    temp = (config.CMS << (CMS_OFFSET));
    TIMRptr->CR1 &= ~(0x3 << (CMS_OFFSET));
    TIMRptr->CR1 |= temp;


    TIMRptr->CR1 &= ~(0x1 << DIR_OFFSET); //count up

    TIMRptr->CR1 &= ~(0x1 << ARPE_OFFSET); //ARB buffer off

    TIMRptr->CR1 &= ~(0x1 << DIR_OFFSET); //count up
    
    TIMRptr->CR1 &= ~(0x1 << OPM_OFFSET); //opm off?

    TIMRptr->CR1 &= ~(0x1 << UDIS_OFFSET);

    TIMRptr->CR1 &= ~(0x1 << URS_OFFSET);

    TIMRptr->PSC |= config.PSC; //might need to clear first?

    TIMRptr->ARR |= config.ARV;

     TimerInterrupt(TIMRptr);
}

void TimerStart(GPTIMR_RegDef_t *TIMRptr){
    TIMRptr->CR1 |= ACTIVE; //no shift because CEN is bit 0?
}

void TimerStop(GPTIMR_RegDef_t *TIMRptr){
    TIMRptr->CR1 &= ~(ACTIVE);
}

void TimerRst(GPTIMR_RegDef_t *TIMRptr){
    TIMRptr->CNT = 0;
}

uint32_t getTimerARV(GPTIMR_RegDef_t *TIMRptr){
    return TIMRptr->ARR; //I think this returns the ARV?
}

uint32_t getTimerCnt(GPTIMR_RegDef_t *TIMRptr){
    return TIMRptr->CNT;
}

void TimerInterrupt(GPTIMR_RegDef_t *TIMRptr){
    enableIRQ(TIM2_IRQ_NUMBER);
}


